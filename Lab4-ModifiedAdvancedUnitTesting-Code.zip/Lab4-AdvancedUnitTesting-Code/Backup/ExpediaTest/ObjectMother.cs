using Expedia;
using System;

namespace ExpediaTest
{
	public class ObjectMother
	{
		
	}
}
